Lexi15 Android project.
Open this folder in Android Studio.
Then: Build > Build Bundle(s) / APK(s) > Build APK(s).
The APK will be in app/build/outputs/apk/debug/app-debug.apk
